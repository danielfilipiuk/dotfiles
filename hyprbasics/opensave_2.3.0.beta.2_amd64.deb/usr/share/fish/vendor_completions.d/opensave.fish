# fish completion for opensave
complete -c opensave -n __fish_use_subcommand -a add -d 'Track a save folder'
complete -c opensave -n __fish_use_subcommand -a backup -d 'Portable backup archive'
complete -c opensave -n __fish_use_subcommand -a branch -d 'Create a branch'
complete -c opensave -n __fish_use_subcommand -a branch-delete -d ''
complete -c opensave -n __fish_use_subcommand -a checkout -d 'Switch branch'
complete -c opensave -n __fish_use_subcommand -a cloud -d ''
complete -c opensave -n __fish_use_subcommand -a completion -d ''
complete -c opensave -n __fish_use_subcommand -a config -d 'Read/write settings'
complete -c opensave -n __fish_use_subcommand -a conflicts -d 'Saves needing a decision'
complete -c opensave -n __fish_use_subcommand -a daemon -d 'Run or control the daemon'
complete -c opensave -n __fish_use_subcommand -a exclude -d 'Folders to skip when scanning'
complete -c opensave -n __fish_use_subcommand -a export -d 'Copy a save out'
complete -c opensave -n __fish_use_subcommand -a files -d ''
complete -c opensave -n __fish_use_subcommand -a forget -d ''
complete -c opensave -n __fish_use_subcommand -a game -d ''
complete -c opensave -n __fish_use_subcommand -a help -d 'Show help'
complete -c opensave -n __fish_use_subcommand -a ignore -d 'Files that should not sync'
complete -c opensave -n __fish_use_subcommand -a install -d ''
complete -c opensave -n __fish_use_subcommand -a launch -d ''
complete -c opensave -n __fish_use_subcommand -a link -d 'Treat two games as one'
complete -c opensave -n __fish_use_subcommand -a links -d 'Show linked ids'
complete -c opensave -n __fish_use_subcommand -a locations -d 'Extra save folders for a game'
complete -c opensave -n __fish_use_subcommand -a pair -d 'Pair a device'
complete -c opensave -n __fish_use_subcommand -a peers -d 'List devices'
complete -c opensave -n __fish_use_subcommand -a probe -d ''
complete -c opensave -n __fish_use_subcommand -a prune -d ''
complete -c opensave -n __fish_use_subcommand -a relay -d 'Internet sync'
complete -c opensave -n __fish_use_subcommand -a remove -d 'Stop tracking a game'
complete -c opensave -n __fish_use_subcommand -a resolve -d 'Settle a conflict'
complete -c opensave -n __fish_use_subcommand -a rollback -d 'Restore a snapshot'
complete -c opensave -n __fish_use_subcommand -a scan -d 'Auto-detect game saves'
complete -c opensave -n __fish_use_subcommand -a scanpath -d ''
complete -c opensave -n __fish_use_subcommand -a service -d 'Install as a service'
complete -c opensave -n __fish_use_subcommand -a snapshot -d 'Create a snapshot'
complete -c opensave -n __fish_use_subcommand -a snapshot-delete -d ''
complete -c opensave -n __fish_use_subcommand -a snapshots -d 'List snapshots'
complete -c opensave -n __fish_use_subcommand -a status -d 'Show tracked games and peers'
complete -c opensave -n __fish_use_subcommand -a sync -d 'Sync now'
complete -c opensave -n __fish_use_subcommand -a unlink -d 'Undo a link'
complete -c opensave -n __fish_use_subcommand -a unpair -d 'Drop a paired device'
complete -c opensave -n __fish_use_subcommand -a untrack-all -d ''
complete -c opensave -n __fish_use_subcommand -a update -d ''
complete -c opensave -n __fish_use_subcommand -a upnp -d 'Forward a router port'
complete -c opensave -n __fish_use_subcommand -a version -d 'Print the version'
complete -c opensave -n '__fish_seen_subcommand_from pair' -a requests
complete -c opensave -n '__fish_seen_subcommand_from pair' -a approve
complete -c opensave -n '__fish_seen_subcommand_from pair' -a reject
complete -c opensave -n '__fish_seen_subcommand_from relay' -a status
complete -c opensave -n '__fish_seen_subcommand_from relay' -a join
complete -c opensave -n '__fish_seen_subcommand_from relay' -a leave
complete -c opensave -n '__fish_seen_subcommand_from daemon' -a start
complete -c opensave -n '__fish_seen_subcommand_from daemon' -a status
complete -c opensave -n '__fish_seen_subcommand_from daemon' -a stop
complete -c opensave -n '__fish_seen_subcommand_from service' -a install
complete -c opensave -n '__fish_seen_subcommand_from service' -a uninstall
complete -c opensave -n '__fish_seen_subcommand_from service' -a status
complete -c opensave -n '__fish_seen_subcommand_from exclude' -a list
complete -c opensave -n '__fish_seen_subcommand_from exclude' -a add
complete -c opensave -n '__fish_seen_subcommand_from exclude' -a remove
complete -c opensave -n '__fish_seen_subcommand_from scanpath' -a list
complete -c opensave -n '__fish_seen_subcommand_from scanpath' -a add
complete -c opensave -n '__fish_seen_subcommand_from scanpath' -a remove
complete -c opensave -n '__fish_seen_subcommand_from game' -a set
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a connect
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a setup
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a disconnect
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a status
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a browse
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a list
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a push
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a restore
complete -c opensave -n '__fish_seen_subcommand_from cloud' -a delete
complete -c opensave -n '__fish_seen_subcommand_from resolve' -a keep-both
complete -c opensave -n '__fish_seen_subcommand_from resolve' -a keep-local
complete -c opensave -n '__fish_seen_subcommand_from resolve' -a keep-remote
complete -c opensave -n '__fish_seen_subcommand_from backup' -a export
complete -c opensave -n '__fish_seen_subcommand_from backup' -a import
complete -c opensave -n '__fish_seen_subcommand_from config' -a list
complete -c opensave -n '__fish_seen_subcommand_from config' -a set
complete -c opensave -n '__fish_seen_subcommand_from locations' -a add
complete -c opensave -n '__fish_seen_subcommand_from locations' -a remove
complete -c opensave -n '__fish_seen_subcommand_from ignore' -a add
complete -c opensave -n '__fish_seen_subcommand_from ignore' -a remove
complete -c opensave -n '__fish_seen_subcommand_from ignore' -a clear
complete -c opensave -n '__fish_seen_subcommand_from ignore' -a test
complete -c opensave -l json -d 'Machine-readable output'
