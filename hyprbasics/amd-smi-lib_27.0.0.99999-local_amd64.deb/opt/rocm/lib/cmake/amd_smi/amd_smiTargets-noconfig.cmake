#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "amd_smi" for configuration ""
set_property(TARGET amd_smi APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(amd_smi PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libamd_smi.so.27.0.0"
  IMPORTED_SONAME_NOCONFIG "libamd_smi.so.27"
  )

list(APPEND _cmake_import_check_targets amd_smi )
list(APPEND _cmake_import_check_files_for_amd_smi "${_IMPORT_PREFIX}/lib/libamd_smi.so.27.0.0" )

# Import target "amdsminic" for configuration ""
set_property(TARGET amdsminic APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(amdsminic PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NOCONFIG "CXX"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libamdsminic.a"
  )

list(APPEND _cmake_import_check_targets amdsminic )
list(APPEND _cmake_import_check_files_for_amdsminic "${_IMPORT_PREFIX}/lib/libamdsminic.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
