A.OS/2 VIA Audio Drivers
  
  There should be 8 files in VIA Audio Driver Directory.
  
  CONTROL.SRC : This file tells MINSTALL that subsystems and
                devices that the user can install.
  AUDFILES.SRC: This file tells  MINSTALL which files need to 
                be copied, and into which subdirectories those files
                should be copied.
  CARDINFO.DLL: The file contains information relevant to the audio 
                adapter. MMPM/2 uses this information to interface with
                the adapter.
  AUDHELP.HLP : The file gives information to the user when the user
                installs the audio adapter.
  GENIN.DLL   : The file the generic installation program that installs 
                your audio adapter.
  GENINMRI.DLL: Contains the text used be GENIN.DLL.
  VIAUDD.SYS  : VIA Audio Physicl Device Driver.
  README.TXT  : This file.
 
   
B.Install VIA Audio Driver In Window OS/2

1. Place the installation diskette in drive A.
2. Type MINSTALL on the OS/2 command line.
3. Change the source drive to A.
4. Select the adpater, then press "OK"
5. If error occur, check the MINSTALL.LOG file in the \MMOS2\INSTALL 
   subdirectory for error message.
