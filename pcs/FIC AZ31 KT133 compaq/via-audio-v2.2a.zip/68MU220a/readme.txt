  ������������������������������������������������������������������������Ŀ
  �              Copyright (c) 1998-2001 VIA Technologies Inc.             �
  �                                                                        �
  �               VIA AC'97 PCI Audio Device Driver ReadMe.Txt             �     
  �                                  for                                   �
  �                DOS/Win9x/Win40/Win2000/WinME/WinXP/Linux               �
  �                                                                        �
  � * This readme file is used to provide the information for installation �
  �   and Uninstall "VIA AC'97 PCI Audio Device" drivers.                  �
  ��������������������������������������������������������������������������


                                CONTENTS
                        ***********************
1)  Hardware Recommend
2)  System Requirements
3)  Package Version Identify
4)  Distribution Package Contents
5)  DOS 
6)  Windows 95 Driver
7)  Windows 98 Driver
8)  Windows 2000/XP Driver
9)  Windows ME Driver
10) Windows NT 4.0 Driver
11) Linux Driver
12) OS/2 Driver
                        ***********************

1) Hardware Recommend
   The Pentinum II 266 MHz CPU (or Pentinum 200 MHz CPU) and 32 MB Ram are 
   recommended to keep the sound quaility.


2) System Requirements

   * This package could be installed for the Audio function of VIA VT82C686A/686B/VT8231

   * The "VIA AC97 PCI Audio Device" driver package supports the drivers on
     the following Operation Systems.

        Operation System                Version             
     ���������������������������������������������������������������
        DOS*                            6.22
        Windows 95                      4.00.950 or above
        Windows 98                      4.10.1998 or above
	Windows NT 3.51
        Windows NT 4.0                  Service Pack 4 ,build 1381
        Windows 2000                    RTM or above
	Windows Me			RC1 or above
        Linux                           RedHat 6.0/6.1/6.2/7.0/7.1
                                        RedFlat 1.0/2.0 for China
					OpenLinux 2.2
					Happy Linux 2.0
					Kernel 2.2.16
					Kernel 2.4.0	
	OS/2

        * Note : The EMM386.EXE above the DOS 6.22 handles the NMI routine
                 unproperly when DOS program is used the NMI ISR also. 

3) Package Version Identify

    1. In this package, there is a TXT file named VIAUDIO.REV. You can see
       this package release version in this file. ex. If you can see 2.20a
       in this file, our Setup program will show 2.20a in driver installation
       screen.

    2. This package release version is 2.20a.

    3. The driver version included in this package(Ver 2.20a)

        Operation System                Version             
     ���������������������������������������������������������������
        DOS*                            1.11
        Windows 9x(VXD)                 4.05.00.1130     
        Windows 98SE (WDM)              5.12.01.3622
	Windows NT 3.51			4.00.Beta
        Windows NT 4.0                  4.03.00.3140
        Windows 2000/XP(WDM)            5.12.01.3622
        Windows ME(WDM)                 5.12.01.3622
        Linux                           1.20
	OS/2				1.11

4) Distribution Package Contents  
     This distribution floppy is compressed by auto uncompressing format. You 
   should uncompress it first by execute it directly.
 
   The uncompressed package includes the following files listed below : 

FLOPPY :
�
�   _INST32I.EX_                Setup Program
�   _ISDEL.EXE                  InstallShield5 related files below
�   _SETUP.DLL
�   _SYS1.CAB
�   _SYS1.HDR
�   _USER1.CAB
�   _USER1.HDR
�   DATA.TAG
�   DATA1.CAB
�   DATA1.HDR
�   LANG.DAT
�   LAYOUT.BIN
�   OS.DAT
�   SETUP.BMP
�   SETUP.EXE
�   SETUP.INI
�   SETUP.INS
�   SETUP.ISS
�   SETUP.LID
�   WDM.BAT
�
����DOS                         
�       INSTALL.EXE             VIA Sound Blaster Pro Compatible setup program
�       VIAUDIO.COM             VIA Sound Blaster Pro Compatible TSR program
�       DOS4GW.EXE              Enter Protect mode Watcom DOS4GW program
�
����WIN9X 
�       VIAUDIO.INF             VIA AC97 PCI Audio Device installation file
�       VIAJSTIC.INF            VIA AC97 PCI Audio Game port installation file
�       VIAUDIO.VXD             VIA AC97 PCI Audio Device VxD driver
�       VIAWAVE.DRV             VIA AC97 PCI Audio Device Wave driver
�       VIAFM.DRV               VIA AC97 PCI Audio Device FM driver
�       VIAMIDE.DRV             VIA AC97 PCI Audio Device MPU401 driver
�
����WIN98SE 
�       VIAUDIO.INF             VIA AC97 PCI Audio Device installation file (Note : it is same as the one in Win2000 directory.)
�       VIAUDIO.SYS             VIA AC97 PCI Audio Deivce WDM driver (Note : it is same as the one in Win2000 directory.)
�       VIAUDIO.CAT             VIA AC97 MS Digital Signature Catalog file
� 
����WIN2000 
�       VIAUDIO.INF             VIA AC97 PCI Audio Device installation file.
�       VIAUDIO.SYS             VIA AC97 PCI Audio Deivce WDM driver.
�       VIAUDIO.CAT             VIA AC97 MS Digital Signature Catalog file
� 
����WINXP 
�       VIAUDIO.INF             VIA AC97 PCI Audio Device installation file.
�       VIAUDIO.SYS             VIA AC97 PCI Audio Deivce WDM driver.
�       VIAUDIO.CAT             VIA AC97 MS Digital Signature Catalog file
�
����WINME 
�       VIAUDIO.INF             VIA AC'97 Audio Device installation file. (Note : it is same as the one in Win2000 directory.)
�       VIAUDIO.SYS             VIA AC'97 Audio Deivce WDM driver. (Note: it is different with the one in Win2000 directory for MS DRM requirement.)
�       VIAUDIO.CAT             VIA AC'97 Audio Deivce Digital Signed file 
�        
����WINNT40 
�       OEMSETUP.INF            VIA AC97 PCI Audio Device installation file
�       VIAUDIO.SYS             VIA AC97 PCI Audio Deivce kernel mode driver 
�       VIAUDIO.DLL             VIA AC97 PCI Audio Device user mode driver
�
����WINNT351                         
�       OEMSETUP.INF		VIA AC97 PCI Audio Device installation file 
�       VIAUDIO.SYS		VIA AC97 PCI Audio Deivce kernel mode driver
�       VIAUDIO.DLL		VIA AC97 PCI Audio Device user mode driver
�
����OS2                         
�	AUDFILES.SCR		This file tells  MINSTALL which files need to 
�				be copied, and into which subdirectories those files
�				should be copied.
�	AUDHELP.HLP		The file gives information to the user when the user
�				installs the audio adapter.
�	CARDINFO.DLL		The file contains information relevant to the audio 
�				adapter. MMPM/2 uses this information to interface with
�				the adapter.
�	CONTROL.SCR		This file tells MINSTALL that subsystems and
�				devices that the user can install.
�	GENIN.DLL		The file the generic installation program that installs 
�				your audio adapter.
�	GENINMRI.DLL		Contains the text used be GENIN.DLL.
�  	VIAUDD.SYS  		VIA Audio Physicl Device Driver.
�
����LINUX
����LINUX
	�
	��2216
        �     �
        �     �   68AUDIO.2216.GZ       VIA AC97 PCI Audio Device compressed file for kernel 2.2.16
	��240
        �     �
        �     �   68AUDIO.240.GZ       VIA AC97 PCI Audio Device compressed file for kernel 2.4.0
        �� Happy
	�     �	 
	�     �  2.0
        �         68AUDIO.hap20.GZ        VIA AC97 PCI Audio Device compressed file for Happy Linux 2.0
	�
	��REDFLAG
        �     �
   	�     �	1.0
        �     �   68AUDIO.RFLG10.GZ       VIA AC97 PCI Audio Device compressed file for RedFlag 1.0
	�     �
        �     �
   	�     �	2.0
        �         68AUDIO.RFLG20.GZ       VIA AC97 PCI Audio Device compressed file for RedFlag 2.0
	�
	�
	��REDHAT
        �     �
        �     �	6.0 
        �     �   68AUDIO.RHT60.GZ        VIA AC97 PCI Audio Device compressed file for RedHat 6.0
        �     �	6.1
        �     �   68AUDIO.RHT61.GZ        VIA AC97 PCI Audio Device compressed file for RedHat 6.1
   	�     �	6.2
        �     �   68AUDIO.RHT62.GZ        VIA AC97 PCI Audio Device compressed file for RedHat 6.2
   	�     �	6.2lp
        �     �   68AUDIO.RHT62lp.GZ        VIA AC97 PCI Audio Device compressed file for RedHat 6.2lp
        �     � 7.0
        �     �   68AUDIO.RHT70.GZ        VIA AC97 PCI Audio Device compressed file for RedHat 7.0
        �     � 7.1
        �         68AUDIO.RHT71.GZ        VIA AC97 PCI Audio Device compressed file for RedHat 7.1
	�
	�
        �� CALDERA
	      �	 
	      �	2.2
                  68AUDIO.CLA22.GZ        VIA AC97 PCI Audio Device compressed file for
                                	  Caldera OPENLINUX 2.2


5)  DOS 
    A) VIA Sound Blaster Pro Compatible Setup Program
    ****************************************************
    ** VIA Sound Blaster Pro Compatible Setup Program **
    ****************************************************
    Please "Enabled" the Sound Blaster setting on the BIOS first before you
    want to play the Sound Blaster compatible DOS games. You could follow
    the selecting to enable the setting on the BIOS :
    
        INTEGRATED PERIPHERALS -> Onboard Legacy Audio (Enabled)
                                  -> Sound Blaster (Disable -> Enabled) 

    The Sound Blaster Pro Compatible sound chip is integrated into the VIA
    PCI audio device in order to have Sound Blaster compatible DOS games 
    running on the system.
    
    If you want to play those Sound Blaster compatible DOS games under the 
    real mode MS-DOS or the "Restart in MS-DOS" from Win9x. Then you should
    run this setup program to enable the OPL3 MIDI music. Otherwise, the 
    music will not be heard but the sound still could be heard.    

    If you want to play the legacy games on the Windows DOS Box then you 
    need not to install this program.        

    ***************************************************
    ** VIA Sound Blaster Pro Compatible Installation **
    ***************************************************
    You could enable the Sound Blaster Pro compatible funciton by using
    this setup program.

    a) You should enable the Sound Blaster first on the BIOS setting of 
       the "On board Legacy Audio".

    b) Run the "install.exe".

        A> INSTALL

    c) The program will copy the relative files into the directory which
       you assigned. Then the program will insert the following new line
       into the AUTOEXEC.BAT and copy the original AUTOEXEC.BAT to 
       AUTOEXEC.VIA.

       C:\VIAUDIO\VIAUDIO.COM

    d) Reboot the system when the installation is completed.  

    *****************************************************
    ** VIA Sound Blaster Pro Compatible Uninstallation **
    *****************************************************
    You could uninstall this program by delete the line from the AUTOEXEC.BAT.

       C:\VIAUDIO\VIAUDIO.COM


6)  Windows 9X VxD Driver
    *************************
    ** Driver Installation **
    *************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Install" to do all of 
       installation. After the system reboot, the driver will be installed 
       completely.
       
       If you type 

                D:> SETUP.EXE -WDM 

       then the WDM driver will be installed if it is on the Win98 System.        
          

     b) The "PCI Audio Multimedia Device" will be displayed if the "VIA AC97 PCI
        Audio Device" is detected by the PCI enumerator.

        Set the source destination directory to the "\WIN95" where the "VIA AC97
        PCI Audio Device" installation file, VIAUDIO.INF, for the Win95 is located.

        After the selection, the "VIA AC97 PCI Audio Device" and its subsystems
        will be installed automatically. The "VIA AC97 PCI Audio Device" could
        work when the installation is completed.

    ***************************
    ** Driver Uninstallation **
    ***************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Remove" to do all of 
       uninstallation. After the system reboot, the driver will be removed 
       completely.

    b) You could remove the "VIA AC97 PCI Audio Device" from the device manager.
       After the uninstallation, the "VIA AC97 PCI Audio Device" and its subdevice
       will be removed when the removing is completed.

       If you want to totally remove this driver, you should delete the relative
       "VIAUDIO.INF" under the "\WINDOWS\INF" or "WINDOWS\INF\OTHER" directory.
       On the same time, you should remove the driver file under the 
       "WINDOWS\SYSTEM32\VIAUDIO.SYS". Then the driver will not install again
       after next boot.

    *************************************************
    ** Sound Blaster Compatible DOS Game Supported **
    *************************************************
    You could play the Sound Blaster compatible DOS games with OPL3 MIDI 
    music format on the Windows DOS box. But you need to enable the Sound
    Blaster on the BIOS first.
   
    Please "Enabled" the Sound Blaster setting on the BIOS first before you
    want to play the Sound Blaster compatible DOS games. You could follow
    the selecting to enable the setting on the BIOS :
    
        INTEGRATED PERIPHERALS -> Onboard Legacy Audio (Enabled)
                                  -> Sound Blaster (Disable -> Enabled) 

    If the Sound Blaster is not enabled on the BIOS then you could only
    hear the OPL3 MIDI music without the wave sound.

    You need not to install the "VIA Sound Blaster Pro Compatible Setup 
    Program" under the Windows.  
        
    
7)  Windows 98 SE (WDM) Driver
    *************************
    ** Driver Installation **   
    *************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Install" to do all of 
       installation. After the system reboot, the driver will be installed 
       completely.

    b) The "PCI Audio Multimedia Device" will be displayed if the "VIA AC97 PCI
       Audio Device" is detected by the PCI enumerator.

       Set the source destination directory to the "\WIN98" where the "VIA AC97
       PCI Audio Device" installation file, VIAUDIO.INF, for the Win98 is located.

       After the selection, the "VIA AC97 PCI Audio Device" and its subsystems
       will be installed automatically. The "VIA AC97 PCI Audio Device" could
       work when the installation is completed.

    ***************************
    ** Driver Uninstallation **    
    ***************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Remove" to do all of 
       uninstallation. After the system reboot, the driver will be removed 
       completely.

    b) You could remove the "VIA AC97 PCI Audio Device" from the device manager.
       After the uninstallation, the "VIA AC97 PCI Audio Device" and its subdevice
       will be removed when the removing is completed.

       If you want to totally remove this driver, you should delete the relative
       "VIAUDIO.INF" under the "\WINDOWS\INF" or "WINDOWS\INF\OTHER" directory.
       On the same time, you should remove the driver file under the 
       "WINDOWS\SYSTEM32\VIAUDIO.SYS". Then the driver will not install again
       after next boot.

    *************************************************
    ** Sound Blaster Compatible DOS Game Supported **
    *************************************************
    You could play the Sound Blaster compatible DOS games with GENERAL MIDI 
    music format ONLY on the Windows DOS box. You need not to enable the 
    "Sound  Blaster" setting on the BIOS. The Sound Blaster emulation is 
    done by Microsoft and the OPL3 music format is not supported anymore
    based on the Microsoft WDM driver archetecture. 

    You should change the MUSIC setting on your Sound Blaster compatible 
    DOS game from FM MIDI to GENERAL MIDI. Otherwise, there is no music
    heard when the Sound Blaster compatible game is played.


8) Windows 2000/XP Driver
    *************************
    ** Driver Installation **   
    *************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Install" to do all of 
       installation. After the system reboot, the driver will be installed 
       completely.

    b) The "PCI Audio Multimedia Device" will be displayed if the "VIA AC97 PCI
       Audio Device" is detected by the PCI enumerator.

       Set the source destination directory to the "\WIN2000" where the "VIA AC97
       PCI Audio Device" installation file, VIAUDIO.INF, for the Win2000 is 
       located.

       After the selection, the "VIA AC97 PCI Audio Device" will be installed
       successfully. The "VIA AC97 PCI Audio Device" could work when the 
       installation is completed.

    ***************************
    ** Driver Uninstallation **    
    ***************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Remove" to do all of 
       uninstallation. After the system reboot, the driver will be removed 
       completely.

    b) You could remove the "VIA AC97 PCI Audio Device" from the device manager.
       After the uninstallation, the "VIA AC97 PCI Audio Device" will be removed
       when the removing is completed.

       If you want to totally remove this driver, you should delete the relative
       "OEMx.INF" under the "\WINDOWS\INF" directory. On the same time, you 
       should remove the driver file under the "WINDOWS\SYSTEM32\VIAUDIO.SYS". 
       Then the driver will not install again after next boot.

       * The .cat file can't be installed from setup program and we need to 
         use the Device Manager to check the "Digital Signed file". 

9) Windows ME Driver
    *************************
    ** Driver Installation **   
    *************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Install" to do all of 
       installation. After the system reboot, the driver will be installed 
       completely.

    b) The "PCI Audio Multimedia Device" will be displayed if the "VIA AC'97 
       Audio Device" is detected by the PCI enumerator.

       Set the source destination directory to the "\WINME" where the "VIA AC'97
       Audio Device" installation file, VIAUDIO.INF, for the Win2000 is 
       located.

       After the selection, the "VIA AC'97 Audio Device" will be installed
       successfully. The "VIA AC'97 Audio Device" could work when the 
       installation is completed.

    ***************************
    ** Driver Uninstallation **    
    ***************************
    a) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Remove" to do all of 
       uninstallation. After the system reboot, the driver will be removed 
       completely.

    b) You could remove the "VIA AC'97 Audio Device" from the device manager.
       After the uninstallation, the "VIA AC'97 Audio Device" will be removed
       when the removing is completed.

       If you want to totally remove this driver, you should delete the relative
       "VIAUDIO.INF" under the "\WINDOWS\INF" or "WINDOWS\INF\OTHER" directory.
       On the same time, you should remove the driver file under the 
       "WINDOWS\SYSTEM32\VIAUDIO.SYS". Then the driver will not install again
       after next boot.

10) Windows NT 4.0 Driver
    *************************
    ** Driver Installation **   
    *************************
    A) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Install" to do all of 
       installation. After the system reboot, the driver will be installed 
       completely.

    B) You could follow the instructions listed below to install the driver :

       a) Select the "Multimedia" icon from the Control Pannel to install 
          this driver.

       b) When the "Multimedia Properties" is displayed, select the "Devices"
          sheet then click the "Add" button. 

       c) When the "Add" page is displayed, select the "Unlisted or Upgrated 
          Driver" from the "List of Drivers". Then click "OK" button.

       d) Type the source volumn and "\WINNT40" directory where the driver 
          located. Then click "OK" button.

       e) The "VIA AC97 PCI Audio Device" will be displayed on the 
          "Add Unlisted on Updated Driver" page. Select "OK" then the driver
          will be installed into the system.

    If you want to use the Joystick Device then follow the procedures listed
    below :
 
       f) Select "Joystick Devices" on the "Multimedia Properties" then click
          "OK" button.
       
       g) Select the joystick from the "List of Drivers" or from the "Unlisted
          or Upgrated Driver" which is supported from the Joystick manufactors.
    
    After the selection, the "VIA AC97 PCI Audio Device" and its subsystems
    will be installed automatically. The "VIA AC97 PCI Audio Device" could
    work when the installation is completed.
    
    ***************************
    ** Driver Uninstallation **    
    ***************************
    You could follow the instructions listed below to uninstall the driver :

    A) Type 
                D:> SETUP.EXE

       to install from the setup program. Select "Remove" to do all of 
       uninstallation. After the system reboot, the driver will be removed 
       completely.

    B) You could follow the instructions listed below to remove the driver :

       a) Select the "Multimedia" icon from the Control Pannel to uninstall 
          this driver.

       b) When the "Multimedia Properties" is displayed, select the "Devices"
          sheet then click the "Remove" button. 

       c) When the "Remove" page is displayed, click the "OK" button then
          the driver will be removed. 
                                   
11)  LINUX
    *************************
    ** Driver Installation **   
    *************************
    You could follow the instructions listed below to install the driver :
    
    A) Login as a super user.

    B) Change directory accroding to the Linux version, e.g..

       # mcd a:/linux/redhat

       for RedHat and 

       # mcd a:/linux/caldera

       for Caldera OpenLinux. 

    C) Copy compress file accroding to the Linux version to a certain 
       directory, e.g..
        
       # mkdir ./viaudio
       # mcopy a:68rht60.gz ./viaudio

       for RedHat 6.0 and
        
       # mcopy a:68cla22.gz ./viaudio 

       for Caldera OpenLinux 2.2.   

    D) Uncompress the compress file by using tar command, e.g.

       # tar xzvf 68rht60.gz

       for RedHat 6.0 and

       # tar xzvf 68cla22.gz

       for Caldera OpenLinux 2.2.


    E) Change directory to the relative directory to do the installation.  
 
       # ./vinstall

       For RedHat 6.0, this program will overwrite some files, e.g. 

		/lib/modules/2.2.5-15/misc/soundcore.o
		/lib/modules/2.2.5-15/modules.dep

       and copy some files, e.g. 

		/lib/modules/2.2.5/sound/viaudio.o

       and backup the original files as the following :
 
		/lib/modules/2.2.5-15/misc/bak/soundcore.o.old
		/lib/modules/2.2.5-15/modules.dep.old


       For Caldera OpenLinux 2.2, this program will overwrite some 
       files, e.g. 

		/lib/modules/2.2.5/sound/soundcore.o

       and copy some files, e.g. 

		/lib/modules/2.2.5/sound/viaudio.o

       and backup the original files as the following
 
		/lib/modules/2.2.5/sound/bak/soundcore.o.old

       then modify 
        
                /etc/modules.conf 

        After the installation, the VIA Audio Linux driver could be 
        loaded on the Caldera OpenLinux 2.2. 

 
    * Please turn on the USB Host Controller and USB 2 Host Controller on
      the BIOS setting first. Otherwise, the Audio function will not detect
      by LINUX 2.2.5 kernel. It is the LINUX 2.2.5 kernels' bug.    

    ***************************
    ** Driver Uninstallation **    
    ***************************
    You could follow the instructions listed below to uninstall the driver :

    A) Login as a super user.

    B) Change directory to the relative directory to do the uninstallation
       by typing :  

       # ./vunstall
        
       After the uninstallation, the the VIA PCI Audio driver will be removed
       from the system.

    *************************
    ** Note for RedHat 7.1 **    
    *************************
    If system have loaded default driver (writed by kernel developer) ,user have
    to remove it ,then executing vinstall. Otherwise user has to reboot system,
    then it can load viaudio driver.

12) OS/2 Driver
    *************************
    ** Driver Installation **   
    *************************
    (a) Place the installation diskette in drive A.

    (b) Type MINSTALL on the OS/2 command line.

    (c) Change the source drive to A.

    (d)	Select the adpater, then press "OK"

    (e) If error occur, check the MINSTALL.LOG file in the \MMOS2\INSTALL 
        subdirectory for error message.


