[InstallShield Silent]
Version=v5.00.000
File=Response File

[File Transfer]
OverwriteReadOnly=NoToAll

[DlgOrder]
Dlg0=SdFinishReboot-0
Count=1

[SdFinishReboot-0]
Result=1
BootOption=3
