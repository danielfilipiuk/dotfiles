REM this batch file removes the driver from the system
REM

Echo off