[InstallShield Silent]
Version=v5.00.000
File=Response File

[File Transfer]
OverwriteReadOnly=NoToAll

[DlgOrder]
Dlg0=SdWelcome-0
Count=2
Dlg1=RebootDialog-0

[SdWelcome-0]
Result=1

[Application]
Name=SoundMAX
Company=Analog Devices
Lang=0009

[RebootDialog-0]
Result=0
Choice=0
