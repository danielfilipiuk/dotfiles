essdos.zip
a collection of esstech pci soundcard drivers for DOS.

es1938 ESS 1938/41/46 Solo-1 AudioDrive (16bit)
es1941 ESS 1938/41/46 Solo-1 AudioDrive (16bit)
es1946 ESS 1938/41/46 Solo-1 AudioDrive (16bit)
es1968 ESS 1968 Maestro-2 AudioDrive (16bit)
es1978 ESS 1978 Maestro AudioDrive (16bit)
es1980 ESS 1980 Maestro-3 AudioDrive (16bit)
es1989 ESS 1989 Allegro-1 AudioDrive (16bit)

ripped from:
ESS Technology (http://www.esstech.com)

~~~
config.sys
DEVICEHIGH=C:\ESS*****.SYS

autoexec.bat
LH C:\ESS*****.COM


::: tikbalang at yahoo dot com :::
