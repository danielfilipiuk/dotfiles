[InstallShield Silent]
Version=v5.00.000
File=Response File

[DlgOrder]
Dlg0=SdWelcome-0
Count=3
Dlg1=SdStartCopy-0
Dlg2=SdFinishReboot-0

[SdWelcome-0]
Result=1

[SdStartCopy-0]
Result=1

[Application]
Name=P4M266 Driver
Company=S3 Graphics, Inc.
Lang=0009

[SdFinishReboot-0]
Result=1
BootOption=3
