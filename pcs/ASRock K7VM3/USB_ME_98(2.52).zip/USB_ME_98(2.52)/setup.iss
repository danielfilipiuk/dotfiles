[InstallShield Silent]
Version=v5.00.000
File=Response File
[File Transfer]
OverwriteReadOnly=NoToAll
[DlgOrder]
Dlg0=SdWelcome-0
Count=3
Dlg1=AskOptions-0
Dlg2=SdFinishReboot-0
[SdWelcome-0]
Result=1
[AskOptions-0]
Result=1
Sel-0=1
Sel-1=0
[Application]
Name=USB 2.0 Setup program
Version=1.00.000
Company=VIA Technologies, Inc.
Lang=0009
[SdFinishReboot-0]
Result=1
BootOption=3
