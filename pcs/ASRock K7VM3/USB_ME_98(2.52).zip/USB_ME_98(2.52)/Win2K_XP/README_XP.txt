USB 2.0 drivers are provided in Service Pack 1 (SP1) for Windows XP. 

Which is available through Windows Update "http://windowsupdate.microsoft.com/ ".
