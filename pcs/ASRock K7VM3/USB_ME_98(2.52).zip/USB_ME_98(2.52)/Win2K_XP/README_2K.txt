USB 2.0 drivers are provided in Service Pack 4 (SP4) for Windows 2000.

Which is available through Windows Update "http://windowsupdate.microsoft.com/ ".
